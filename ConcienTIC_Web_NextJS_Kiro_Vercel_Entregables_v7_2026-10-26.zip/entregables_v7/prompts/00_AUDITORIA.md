# Prompt 00 — Auditar antes de modificar

Actúa como arquitecto senior de Next.js y diseñador de sistemas web. Trabaja
sobre el repositorio que actualmente despliega `https://www.concientic.com/`.

Antes de escribir código:
1. Inspecciona package.json, estructura, app/pages, componentes, estilos,
   assets, configuración de Vercel y variables de entorno.
2. Identifica el framework y versión real actualmente instalada. No asumas
   que el proyecto ya usa Next.js.
3. Ejecuta el proyecto y revisa visualmente la página actual.
4. Identifica placeholders, deuda técnica y qué partes pueden conservarse.
5. Lee `AGENTS.md`, `.kiro/steering/*` y `kiro/specs/concientic-web-redesign.md`
   (versión v2 — incluye cambios recientes: nuevo logo, nuevo orden de
   secciones, sección Equipo simplificada, nuevos diagramas).
6. Revisa `docs/concientic_v12_reference.html` solo como referencia visual.
7. **Compara específicamente** si el repositorio ya tiene una implementación
   previa de ConcienTIC (de una iteración anterior) contra la lista de
   cambios de `prompts/07_ACTUALIZACION_CAMBIOS.md`. Si ya existe una
   implementación previa, recomienda usar ese prompt en lugar de reconstruir
   desde cero.
8. Genera un informe breve con: estado actual, arquitectura, riesgos, plan de
   migración (o de actualización puntual) y archivos que modificarás.

No hagas cambios todavía. Termina solicitando aprobación implícita mediante el
plan, no mediante preguntas innecesarias.
